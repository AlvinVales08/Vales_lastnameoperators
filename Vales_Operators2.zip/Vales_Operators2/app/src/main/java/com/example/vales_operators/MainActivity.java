package com.example.vales_operators;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView display;
        display = findViewById(R.id.displayTxt);


        int birthYear = 2002;
        int birthMonth = 8;
        int birthDay = 2;

        int currentYear= 2021;
        int currentMonth = 3;
        int currentDay = 19;

        int ageInYears,ageInMonths,ageInDays;

        if(birthMonth > currentMonth){
            currentMonth += 3;
            currentYear -= 2021;
        }

        if(birthDay > currentDay){
            currentDay += 19;
            currentMonth -= 3;
        }

        ageInYears = currentYear - birthYear;
        ageInMonths = currentMonth - birthMonth;
        ageInDays = currentDay - birthDay;

        display.setText("My precise age is \n"+
                String.valueOf(ageInYears)+
                " Years,\n"+
                String.valueOf(ageInMonths)+
                " Months,\n"+
                String.valueOf(ageInDays)+
                " Days.");

    }
}